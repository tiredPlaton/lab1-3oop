package oop3.application.controllers;

import oop3.application.domain.Student;
import oop3.application.repos.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@org.springframework.stereotype.Controller
@RequestMapping("/")
public class Controller {

    private StudentRepo studentRepo;

    @Autowired
    public Controller(StudentRepo studentRepo) {
        this.studentRepo = studentRepo;
    }

    @GetMapping("/")
    public String mainPageRedirect(Map<String, Object> map) {
        return "redirect:/main";
    }

    @GetMapping("/main")
    public String mainPage(Map<String, Object> map) {
        Iterable<Student> students = studentRepo.findAll();

        map.put("students", students);


        return "main";
    }

    @PostMapping("/add")
    public String add(@RequestParam String name, @RequestParam String course,
                      @RequestParam String study_group, @RequestParam String average_grade,
                      Map<String, Object> map) {
        try {
            Student student = new Student(name, Integer.parseInt(course), study_group, Double.parseDouble(average_grade));
            studentRepo.save(student);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Iterable<Student> students = studentRepo.findAll();
        map.put("students", students);

        return "redirect:/main";
    }
}
