package oop3.application.domain;

import jakarta.persistence.*;
import org.springframework.web.bind.annotation.RequestMapping;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    private String name;
    private Integer course;
    private String study_group;
    private Double average_grade;

    public Student() {
    }

    public Student(String name, Integer course, String study_group, Double average_grade) {
        this.name = name;
        this.course = course;
        this.study_group = study_group;
        this.average_grade = average_grade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCourse() {
        return course;
    }

    public void setCourse(Integer course) {
        this.course = course;
    }

    public String getStudy_group() {
        return study_group;
    }

    public void setStudy_group(String study_group) {
        this.study_group = study_group;
    }

    public Double getAverage_grade() {
        return average_grade;
    }

    public void setAverage_grade(Double average_grade) {
        this.average_grade = average_grade;
    }
}