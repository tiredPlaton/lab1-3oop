package oop3.application;

import oop3.application.controllers.Controller;
import oop3.application.repos.StudentRepo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@SpringBootConfiguration
public class OopHzApplication {

    public static void main(String[] args) {
        SpringApplication.run(OopHzApplication.class, args);
    }

}
