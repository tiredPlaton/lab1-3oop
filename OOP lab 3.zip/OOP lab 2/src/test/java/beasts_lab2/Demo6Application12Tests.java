package beasts_lab2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo6Application12Tests {

    @Test
    void contextLoads() {
    }

}
