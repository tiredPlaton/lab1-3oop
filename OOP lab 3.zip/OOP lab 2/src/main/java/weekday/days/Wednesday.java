package weekday.days;

public class Wednesday implements WeekDay {
    private String name = "wednesday";

    @Override
    public String getWeekDayName() {
        return name;
    }
}
