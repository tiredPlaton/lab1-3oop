package weekday.days;

public class Tuesday implements WeekDay{
    private String name = "tuesday";

    @Override
    public String getWeekDayName() {
        return name;
    }
}
