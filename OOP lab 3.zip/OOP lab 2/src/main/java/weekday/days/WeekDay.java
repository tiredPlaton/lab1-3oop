package weekday.days;

public interface WeekDay {
    String getWeekDayName();
}
