package weekday.days;

public class Thursday implements WeekDay{
    private String name = "thursday";

    @Override
    public String getWeekDayName() {
        return name;
    }

}
