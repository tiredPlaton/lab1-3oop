package weekday.days;

public class Saturday implements WeekDay{
    private String name = "saturday";

    @Override
    public String getWeekDayName() {
        return name;
    }
}
