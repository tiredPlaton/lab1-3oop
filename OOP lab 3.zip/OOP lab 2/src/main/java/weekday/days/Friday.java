package weekday.days;

public class Friday implements WeekDay{
    private String name = "friday";

    @Override
    public String getWeekDayName() {
        return name;
    }
}
